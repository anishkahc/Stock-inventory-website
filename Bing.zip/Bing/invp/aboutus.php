<html>
<head > 
<link rel= "stylesheet" type="text/css" href = "aus.css">
</head>
<body>

 <h1> Mini project</h1> <br>
     <h2> Topic: Demo Stock Inventory System.  <br></h2>
	 <h3>     
         The  above project is a demo purpose project to understand basic working of stock and its managemaent at a particular firm. <br>
		 The project is based on basic web application built using PHP, html and CSS for the same. <br>
		 </h3>
	
		 
		 <h2>Credits:<br></h2>
		 <h3>Rasika Kharpate       17<br>
		 Anishka Chaudhari     03<br>
		 Akanksha Singh        02<br>
		 </h3>
		 
		 <h3>
		 Students of Datta Meghe College Of Engineering <br>
		 Second Year , Branch : Information Technology <br>
		 </h3>
		 
 </body>
</html> 
	 
   
     
	 
	 