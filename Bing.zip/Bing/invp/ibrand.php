<?php 
error_reporting(E_PARSE | E_ERROR);
include ('connect.php');
$sql1=mysql_query("select * from brands");
$epr='';
$msg='';
  if(isset($_GET['epr']))
	   $epr=$_GET['epr'];
   
   
   
      //delete
   if($epr=='delete')
   {
		$id=$_GET['id'];
		  $a_deleterow=mysql_query("delete from brands where brandname='$id'");
		   
		if($a_deleterow)
			{header("location:ibrand.php");
		
		}
		  else 
			  $msg='error :'.mysql_error();
   } 
   //save
   if($epr=='save')
   {
	   $name=$_POST['txtn'];
	    $avail=$_POST['txta'];
		$a_sql=mysql_query("insert into brands values('$name','$avail')");
	 
     if($a_sql)	
	     {header("location:ibrand.php");		 
             	 
		 }
	  else
		  $msg='error :'.mysql_error();
   }
   

   // svav update
   
   if($epr=='saveup')
   {
  	   $name=$_POST['txn'];
	   $id=$name;
	   $avail=$_POST['txa'];
	 $a_sql=mysql_query("update brands set brandname='$name',avail='$avail' where brandname='$id' ");  
	 
	   if($a_sql)	
	     {header("location:ibrand.php");		 
             	 
		 }
	  else
		  $msg='error :'.mysql_error();
   }
?>


<html>
<head>
<link rel="stylesheet" type="text/css" href="aus.css">
</head>
<body id="wrapper">
         <?php
		     if($epr=='update'){
			   $id = $_GET['id'];
	         $row = mysql_query("select * from brands where brandname='$id'");
             $st_row1=mysql_fetch_array($row);
	    ?>
			 <h2 align="center"><strong>BRAND LIST</strong></h2><br><br>
		 <h2 align='center'>Update Brand</h2>
          <form method="post" action='ibrand.php?epr=saveup'>
             <table align='center'>
			     <tr>
			         <td>Name:</td>
				     <td><input type='text' name='txn' value="<?php echo $st_row1['brandname']?>"/></td>
				 </tr>
				 <tr>
			         <td>Availability:</td>
				     <td><input type='text' name='txa'value="<?php echo $st_row1['avail']?>"/></td>
				 </tr>
				 <tr>
			         <td></td>
				     <td><input type='submit' name='usave' /></td>
				 </tr>
				 
			 </table>
          </form>
		 <?php }else{ 
			 
		?>			 
			 
		 
		 
		 <h2 align="center"><strong>BRANDS LIST</strong></h2><br><br>
		 <h2 align='center'>Add a new brand</h2>
          <form method="post" action='ibrand.php?epr=save'>
             <table align='center'>
			     <tr>
			         <td>Name:</td>
				     <td><input type='text' name='txtn'/></td>
				 </tr>
				 <tr>
			         <td>Availability:</td>
				     <td><input type='text' name='txta'/></td>
				 </tr>
				 <tr>
			         <td></td>
				     <td><input type='submit' name='bsave'/></td>
				 </tr>
				 
			 </table>
          </form>
		  <?php } ?>

 

<table align="center" border="1" cellspacing="0" width="700">
   <thead>
   <th>NO</th>
     <th>BRAND NAME</th>
	 <th>AVAILABILITY</th>
	 <th>ACTION</th>
     </thead>
	 <?php
	 $i=1;
	 while($row=mysql_fetch_array($sql1))
	 {
		 echo"<tr>
		      <td align='center'>".$i."</td>
			  <td align='center'>".$row['brandname']."</td>
			  <td align='center'>".$row['avail']."</td>
			  <td align='center'>
			       <a href=ibrand.php?epr=delete &id=".$row['brandname'].">DELETE</a>  
				   
			  </td>
			 
			  </tr>";
			  $i++;
	 }
	 ?>
 </table>
  
	</body> 
</html>