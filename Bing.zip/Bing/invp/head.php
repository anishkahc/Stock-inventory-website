<html>
<head>
   <link rel="stylesheet" href="h.css">
</head>
<body>
   <div id ="wrapper">
      
       <header> 
     
    <h1 align="center" vstart="50"><bold> BING SOLUTIONS </h1>
     <h2 align="center"> Online inventory system</h2>
     </header>
       <nav> 
       <ul class="main">
            <li> <a href="home.php" target="sync"> home </a></li>
            <li> <a href="ibrand.php" target="sync"> brand </a></li>
            <li> <a href="icatagory.php" target="sync"> category </a></li>
            <li> <a href="iorder.php" target="sync"> orders </a></li>
             <li> <a href="aboutus.php" target="sync"> about us </a></li>
      </div>
</body>
</html>
