<?php
error_reporting(E_PARSE|E_ERROR);
include('connect.php');
$osql=mysql_query("SELECT * FROM orders");
$von='';
$omsg='';
if(isset($_GET['von']))
	$von=$_GET['von'];
	


//save
if($von=='save')
{
	$oname=$_POST['oname'];
	$odat=$_POST['odate'];
	$oamt=$_POST['oamt'];
	 $o_sql=mysql_query("INSERT INTO orders VALUES ('$oname','$odat','$oamt')");

	 if($o_sql)	
	     header("location:iorder.php");		 
             	 
		 
	  else
		  $msg='error :'.mysql_error();
 }
 ?>

 <html>
 <head>
 <link rel="stylesheet" type="text/css" href="aus.css">
<!--  <script type="text/javascript">
    $(document).ready(function() {
        $('.btn-success').click(function() {
            var id = $(this).attr("id");
            if (confirm("Are you sure you want to delete this Order?")) {
                $.ajax({
                    type: "POST",
                    url: "delete_member.php",
                    data: ({
                        id: id
                    }),
                    cache: false,
                    success: function(html) {
                        $(".delete_mem" + id).fadeOut('slow');
                    }
                });
            } else {
                return false;
            }
        });
    });
</script> -->
 </head>
 <body>
 <h2 align="center">ORDERS</h2>
 <h2 align="center">Add order</h2>
 
    <form align='center' action='iorder.php?von=save'>
	     <table align='center'><tr>
		     <td>Name:</td>
			  <td><input type='text' name='oname'></td>
			  </tr>
			  <tr>
			  <td>Date:</td> 
			  <td><input type='text' name='odat'></td>
			  </tr>
			  <tr>
			   <td>Amount:</td>
			     <td><input type='text' name='oamt'></td>
				 </tr>
				 <tr>
				 <input type='submit' name='btns'>
				 </tr>
		  </table>
	</form>
 
 <table align="center"border="1" cellspacing="0" width="700">
 <thead>
   <th>NO</th>
    <th>ORDER NAME</th>   
	 <th>DATE</th>  
	<th>AMOUNT</th>  
	<th>ACTION</th>  
 
 </thead>
 
 <?php
 $l=1;
   while($rowo=mysql_fetch_array($osql))
   {
	    
      echo"<tr>  
              <td align='center'>".$l."</td> 
			  <td align='center'>".$rowo['ordername']."</td> 
			  <td align='center'>".$rowo['date']."</td> 
			  <td align='center'>".$rowo['amount']."</td> 
			 
			  <td align='center'>
			    <a href='iorder.php?klp='delete'>DELETE</a>
				 
			   </td> 
	   
	      </tr>";
		  $l++;
   }
   ?>
 
 </table>
 </body>
 </html>
 