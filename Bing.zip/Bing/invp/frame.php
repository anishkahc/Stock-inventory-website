<!doctype html>


<html>
<head>
<title>Bing Solutions</title>
</head>
<frameset rows="40%,*">
<frame src= "head.php">
<frame name="sync">
</frameset>
</html>