<?php
    // Start the session
    ob_start();
    session_start();

    // Check to see if actually logged in. If not, redirect to login page
    if (!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] == false) {
        header("Location: frame.php");
    }
?>
<center>
<head><link rel="stylesheet" type="text/css" href="aus.css"></head>
<h1 align="center">Login Successful!</h1>
<a  href="frame.php"> <h2>Click here to continue.</h2> </a><br><br>
<br><br>

<form align="center" method="post" action="logout.php">
    <input type="submit" value="Logout">
</form>
</center>