<!DOCTYPE HTML>

<?php

    // Start the session
    session_start();

    // Defines username and password. Retrieve however you like,
    $username = "user";
    $password = "password";

    // Error message
    $error = "";

    // Checks to see if the user is already logged in. If so, refirect to correct page.
    if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == true) {
        $error = "success";
        header('Location: success.php');
    } 
        
    // Checks to see if the username and password have been entered.
    // If so and are equal to the username and password defined above, log them in.
    if (isset($_POST['username']) && isset($_POST['password'])) {
        if ($_POST['username'] == $username && $_POST['password'] == $password) {
            $_SESSION['loggedIn'] = true;
            header('Location: success.php');
        } else {
            $_SESSION['loggedIn'] = false;
            $error = "Invalid username or password!";
        }
    }
?>

<html>

    <head>
        <title>Login Page</title>
        <link rel="stylesheet" type="text/css" href="aus.css">
    </head>
    
    <body>
    <br>
    <br><br>
    <center><img src="logo.png" width="200" height="200"></center>
        <!-- Output error message if any -->
        <?php echo $error; ?>
        
        <!-- form for login -->
        <form align="center" method="post" action="index.php">
            <h1><label for="username">Username:</label><br/></h1>
            <input type="text" name="username" id="username"><br/>
            <h1><label for="password">Password:</label><br/></h1>
            <input type="password" name="password" id="password"><br/><br><br><br>
            <input type="submit" value="Log In!">
        </form>
    </body>
</html>