<?php
error_reporting(E_PARSE|E_ERROR);
include('connect.php');
$sqlc=mysql_query("select * from catagory");
$klp='';
$msg='';

if(isset($_GET['klp']))
	 $klp=$_GET['klp'];

//save
if($klp=='save')
{
	//id1=$_POST['cname'];
	//$id2=$_POST['ctype'];
	//$id3=$_POST['cavail'];
	$c_sql=mysql_query("insert into catagory values('cname',ctype','cavail')");
	if($c_sql)
	{
		header("location:icatagory.php");
	}
	else
		$msg='error:'.mysql_error();
	
}
//delete

	 if($klp=='delete')
	 {
	$idc=$_GET['id'];
	$c_sql_del=mysql_query("delete * from catagory where brandname='$idc' ");
	if($c_sql_del)
	{
		header("location:icatagory.php");
	}
	else
		$msg='error:'.mysql_error();
}


?>



<html>
<head>
<link rel="stylesheet" type="text/css" href="aus.css">
</head>
<body>
          <h2 align="center"><strong> CATAGORY LIST</strong></h2>
		  <h2 align="center"> Add new Catagory </h2>
		   <form method="post" action='icatagory.php?klp=save'>
		   
		     <table align='center'>
			 <tr>
			       <td>Name:</td>
				   <td><input type='text' name='cname'/></td>
			</tr>
			
			<tr>
			       <td>Type:</td>
				   <td><input type='text' name='ctype'/></td>
			</tr>
			<tr>
			       <td>Availability:</td>
				   <td><input type='text' name='cavail'/></td>
			</tr>
			<tr>
			       
				   <td><input type='submit' name='btnclk'/></td>
				  
			</tr>
			</table>
			
			<table align='center' border="1" cellspacing="0" width="700">
			<thead>
			  <th>NO</th>
			  <th>CATAGORY NAME</th>
			  <th>TYPE</th>
			 <th>AVAILABILITY</th>
			 <th>ACTION</th>
          </thead>
		  
		  <?php
		   $j=1;
		   while($rowc=mysql_fetch_array($sqlc))
		   {
			   echo "
			         <tr>
					  <td align='center'>".$j."</td>
					   <td align='center'>".$rowc['catagoryname']."</td>
					    <td align='center'>".$rowc['type']."</td>
						 <td align='center'>".$rowc['available']."</td>
						  <td align='center'>
						   <a href=icatagory.php?klp=delete&id=".$rowc['catagoryname'].">DELETE</a>
						   </td>
					 </tr>";
					 $j++;
		   }?>
			
			

</body>
</html>